<meta charset="UTF-8">
<?php

include('db.php'); 
$doc_num =(isset($_POST['doc_num']) ? $_POST['doc_num'] : ''); 
$doc_title = (isset($_POST['doc_title']) ? $_POST['doc_title'] : '');
$doc_name = (isset($_POST['doc_name']) ? $_POST['doc_name'] : ''); 
$doc_start = (isset($_POST['doc_start']) ? $_POST['doc_start'] : '');
$doc_end = (isset($_POST['doc_end']) ? $_POST['doc_end'] : ''); 
$doc_status = (isset($_POST['doc_status']) ? $_POST['doc_status'] : ''); 
$doc_filename = (isset($_POST['doc_filename']) ? $_POST['doc_filename'] : ''); 

 

    $sql = "INSERT INTO documents (id, doc_num, doc_title, doc_name, doc_start, doc_end, doc_status, doc_filename) 
            VALUES ('','$doc_num', '$doc_title', '$doc_name', '$doc_start', '$doc_end', '$doc_status', '$doc_filename')";

    if($con->query($sql)==TRUE){
        echo "<script>";
        echo "alert('เพิ่มคำสั่งแต่งตั้งสำเร็จ');";
        echo "window.location.href='persons.php';";
        echo "</script>";
       }else{
        echo "ERROR".$sql."<BR>".$con->error;

       }

?>