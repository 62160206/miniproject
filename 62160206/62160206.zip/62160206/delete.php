<meta charset="UTF-8">
<?php
include('db.php');
$id = $_GET["id"];
$sql = "DELETE FROM documents WHERE id='$id'"; 
$result = mysqli_query($con, $sql) or die ("Error in query: " . musql_error());
if($result){
    echo "<script type='text/javascript'>";
    echo "window.location = 'persons.php'; ";
    echo "</script>";
}
else{
    echo "<script type='text/javascript'>";
    echo "alert('Error back to delete again');";
    echo "</script>";
}
?>