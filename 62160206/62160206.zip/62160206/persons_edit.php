
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Resume - Start Bootstrap Theme</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">

  </head>
  <body id="page-top">
    <div style="background-image: url('img_girl.jpg');">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
<!-- <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Hw3</span>
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/profile.jpg" alt="">
      </span>
    </a> -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="index.php">หน้าหลัก</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="persons.php">ย้อนกลับ</a>
        </li>
        </ul>
    </div>
  </nav>

  <!-- Masthead -->
  <div class="container d-flex align-items-center flex-column">
  <div class="container-fluid p-0">

 
        </h1>
       </section>

<?php
include('db.php');
$id = $_GET['id'];
$query = "SELECT * FROM documents WHERE id = $id"; 
$result = mysqli_query($con, $query); 
$row = mysqli_fetch_array($result);
//extract($row); 
?>
  <center>
       <div class="container">
        <br><br>
        <h1>- แก้ไขคำสั่งแต่งตั้ง -</h1>
        <br> <br>
        <form class="form-horizontal" action="persons_edit_check.php" method="post">
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">เลขที่คำสั่ง</span>
            </div>
            <input type="text" class="form-control" name="doc_num" value="<?=$row['doc_num']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>

        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">ชื่อคำสั่ง</span>
            </div>
            <input type="text" class="form-control" name="doc_title" value="<?php echo $row['doc_title']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>

        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">ชื่อกรรมการ</span>
            </div>
            <input type="text" class="form-control" name="doc_name" value="<?php echo $row['doc_name']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>

        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">วันที่เริ่มต้น</span>
            </div>
            <input type="text" class="form-control" name="doc_start" value="<?php echo $row['doc_start']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>

        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">วันที่สิ้นสุด</span>
            </div>
            <input type="text" class="form-control" name="doc_end" value="<?php echo $row['doc_end']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>

        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">สถานะคำสั่ง</span>
            </div>
            <input type="text" class="form-control" name="doc_status" value="<?php echo $row['doc_status']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>
         
        <div class="input-group mb-3">
            <div class="input-group-prepend">
                <span class="input-group-text" id="inputGroup-sizing-default">ที่อยู่ไฟล์คำสั่ง</span>
            </div>
            <input type="text" class="form-control" name="doc_filename" value="<?php echo $row['doc_filename']; ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"

        <br>
        <button type="submit" class="btn btn-primary"  id="basic-addon2">แก้ไข </button>
        <button type="reset" class="btn btn-danger">ยกเลิก</button>
        </center>
    </form>


</body>

</html>