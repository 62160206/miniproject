
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Resume - Start Bootstrap Theme</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <!-- Custom styles for this template -->
  <link href="css/resume.min.css" rel="stylesheet">

  </head>
  <body id="page-top">
    <div style="background-image: url('img_girl.jpg');">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
<!-- <a class="navbar-brand js-scroll-trigger" href="#page-top">
      <span class="d-block d-lg-none">Hw3</span>
      <span class="d-none d-lg-block">
        <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="img/profile.jpg" alt="">
      </span>
    </a> --> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="index.php">หน้าหลัก</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="persons.php">คำสั่งแต่งตั้ง</a>
        </li>
      
        </ul>
    </div>
  </nav>
 

  <!-- Masthead -->
  <div class="container d-flex align-items-center flex-column">
  <div class="container-fluid p-0">
  <br><br><br>
  <div class="row">
 <div class="col-md-12">    
    <div class="col-md-9">
    <a href="persons_add.php" class="btn-info btn-sm">เพิ่มคำสั่งแต่งตั้ง</a>
  </div><br>
  <br>

       <div class="card my-8"> 
      <h2 class="card-header">คำสั่งแต่งตั้ง</h2> 
      <div class="container">
        <div class="row justify-content-md-end">
            <div class="col-md-4">
                <form action="#" method="GET">
                <div class="row">
    
                </form>
            </div>
        </div>

<?php
include('db.php');  
$query = "SELECT * FROM documents " or die("Error:" . mysqli_error()); 
$result = mysqli_query($con, $query); 

            echo "<table class = 'table table-hover' >";
            echo "<tr>";
            echo "<th>เลขที่คำสั่ง</th>";
            echo "<th>ชื่อคำสั่ง</th>";
            echo "<th>ชื่อกรรมการ</th>";
            echo "<th>วันที่เริ่มต้น</th>";
            echo "<th>วันที่สิ้นสุด</th>";
            echo "<th>สถานะคำสั่ง</th>";
            echo "<th>Link</th>";
            echo "<th>การดำเนินการ</th>";
            echo "</tr>";
            while ($row = $result->fetch_object()) {
              
                echo "<tr>";
                echo "<td class='text-center'>$row->doc_num</td>";
                echo "<td class='text-center'>$row->doc_title</td>";
                echo "<td class='text-center'>$row->doc_name</td>";
                echo "<td class='text-center'>$row->doc_start</td>";
                echo "<td class='text-center'>$row->doc_end</td>";
               
                if($row->doc_status == 'A'){
                   echo "<td class='text-center'>ยังไม่หมดอายุ</td>";
                } else if ($row->doc_status == 'X') {
                  echo "<td class='text-center'>หมดอายุ</td>";
                }

                echo "<td class='text-center'>$row->doc_filename</td>";
                echo "<td ><button><a href='persons_edit.php?id=$row->id'>แก้ไข</a></button>    
                      <button><a href='delete.php?id=$row->id'>ลบ</a></button></td>";
   
                echo "</tr>";
            }
            echo "</table>";
            mysqli_close($con);
        ?>
    </div>


</body>

</html>