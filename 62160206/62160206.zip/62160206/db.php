<?php

$con= mysqli_connect("localhost","root","","62160206") or die("Error: " . mysqli_error($con));
mysqli_query($con, "SET NAMES 'utf8' "); 
?>