<?php include 'db.php';?>
<body>
<?php
$query = "SELECT * FROM documents WHERE ( doc_num LIKE '%".$_GET["search"]."%'or
                                         doc_name LIKE '%".$_GET["search"]."%' or
                                       doc_filename LIKE '%".$_GET["search"]."%')";
//$objQuery = mysqli_query($query) or die ("Error Query [".$query."]");
$result = mysqli_query($con, $query); 
?>
<table width="1000" align="center" border="1"><br>
<div class="row">
 <div class="col-md-12">    
    <div class="col-md-9">
    </div><br>

  <tr>
    <th width="400"> <div align="center">คำสั่งแต่งตั้ง</div></th>
    <th width="400"> <div align="center">เลขที่คำสั่ง</div></th>
    <th width="400"> <div align="center">ชื่อคำสั่ง </div></th>
    <th width="400"> <div align="center">ชื่อกรรมการ </div></th>
  </tr>
  </style>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<!-- CSS here -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
            <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
            <link rel="stylesheet" href="assets/css/gijgo.css">
            <link rel="stylesheet" href="assets/css/slicknav.css">
            <link rel="stylesheet" href="assets/css/animate.min.css">
            <link rel="stylesheet" href="assets/css/magnific-popup.css">
            <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
            <link rel="stylesheet" href="assets/css/themify-icons.css">
            <link rel="stylesheet" href="assets/css/slick.css">
            <link rel="stylesheet" href="assets/css/nice-select.css">
            <link rel="stylesheet" href="assets/css/style.css">
            <link rel="stylesheet" href="assets/css/responsive.css">
            
<?php
while($row = mysqli_fetch_array($result))
{
?>
  <tr>
    <td><?php echo $row["doc_title"];?></td>
    <td><div align="center"><?php echo $row["doc_num"];?></div></td>
    <td align="right"><?php echo $row["doc_name"];?></td>
    <td align="right"><?php echo $row["doc_filename"];?></td>
   

    
  </tr>
 
<?php
}
?>
</table>
<div align="center">
             <br>
             <br>
             <br>
             
            </div>
<?php
   //<figure><img src="images/lala.gif" width="400" hight="200"></figure>
mysqli_close($con);
?>
</body>
</html>


