<?php
//1. เชื่อมต่อ database: 
include('db.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี


//สร้างตัวแปรสำหรับรับค่าที่นำมาแก้ไขจากฟอร์ม
    $id = $_POST["id"];
	$doc_num = $_POST["doc_num"];
	$doc_title = $_POST["doc_title"];
	$doc_name = $_POST["doc_name"];
	$doc_start = $_POST["doc_start"];	
	$doc_end = $_POST["doc_end"];
    $doc_status = $_POST["doc_status"];
    $doc_filename = $_POST["doc_filename"];
  

//ทำการปรับปรุงข้อมูลที่จะแก้ไขลงใน database 
	
	$sql = "UPDATE documents SET  
			doc_num='$doc_num' ,
			doc_title='$doc_title' , 
			doc_name='$doc_name' ,
			doc_start ='$doc_start' ,
			doc_end='$doc_end'  ,
            doc_status='$doc_status' ,
            doc_filename='$doc_filename' 
			WHERE id='$id' ";

$result = mysqli_query($con, $sql);//or die ("Error in query: $sql " . mysqli_error());

mysqli_close($con); //ปิดการเชื่อมต่อ database 

//จาวาสคริปแสดงข้อความเมื่อบันทึกเสร็จและกระโดดกลับไปหน้าฟอร์ม
	
	if($result){
	echo "<script type='text/javascript'>";
	echo "alert('Update Succesfuly');";
    echo "window.location = 'persons.php'; ";
	echo "</script>";
	}
	else{
	echo "<script type='text/javascript'>";
	echo "alert('Error back to Update again');";
         echo "window.location = 'persons_edit.php'; ";
	echo "</script>";
}
?>